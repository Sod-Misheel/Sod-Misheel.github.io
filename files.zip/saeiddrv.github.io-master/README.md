# Naughty Template

This is my personal profile page, where I showcase links to my social media profiles and projects. The page is designed to be simple, modern, and responsive, using a combination of HTML, CSS, and Font Awesome icons.

## License

This project is licensed under the MIT License.

## Acknowledgments

* This template was inspired by Linktree and other similar profile page designs.
* Special thanks to Font Awesome for providing the icons used in this template.

